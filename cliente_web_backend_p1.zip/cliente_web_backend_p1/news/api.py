import time

from rest_framework import viewsets
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from news.models import Noticia
from .serializers import NoticiaListSerializer, NoticiaDetailSerializer


class NoticiaViewSet(viewsets.ModelViewSet):
	queryset = Noticia.objects.all()
	permission_classes = (AllowAny,)

	def get_serializer_class(self):
		return NoticiaListSerializer if self.action == 'list' else NoticiaDetailSerializer

	def list(self, request, *args, **kwargs):
		time.sleep(0.5)  # Simulamos latencia
		return Response(self.get_serializer(self.get_queryset(), many=True).data)

	def create(self, request, *args, **kwargs):
		serializer = self.get_serializer(data=request.data)
		serializer.is_valid(raise_exception=True)
		_ = self.perform_create(serializer)
		return Response(NoticiaListSerializer(self.get_queryset(), many=True).data)
