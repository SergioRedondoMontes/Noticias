from rest_framework import serializers

from news.models import Noticia


class NoticiaListSerializer(serializers.HyperlinkedModelSerializer):
    pub_date = serializers.DateTimeField(format="%d-%m-%Y %H:%M:%S", required=False, read_only=True)

    class Meta:
        model = Noticia
        fields = ['id', 'title', 'header', 'pub_date', 'img_url']


class NoticiaDetailSerializer(NoticiaListSerializer):
    class Meta(NoticiaListSerializer.Meta):
        fields = NoticiaListSerializer.Meta.fields + ['content', 'img2_url']
